import NotFound from '../Assest/images/NotFound.jpg'

const NoteFound = () =>{
    return(
        // <h2>404 - Not Found!</h2>
        <img src={NotFound} style={{width:"30%",margin:"80px 0px 0px 35%"}}></img>


    )
}
export default NoteFound;